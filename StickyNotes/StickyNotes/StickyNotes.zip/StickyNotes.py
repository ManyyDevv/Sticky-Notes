import tkinter
main_window=tkinter.Tk()

main_window.minsize(300,300)
main_window.maxsize(300,300)
main_window.title("Sticky Notes")
text_widget = tkinter.Text(main_window)
text_widget.configure(font = ("Arial"))
text_widget.insert('insert',"Add somes texts !")
text_widget.pack(anchor = "w", padx = 5, pady = 5)

main_window.mainloop()


